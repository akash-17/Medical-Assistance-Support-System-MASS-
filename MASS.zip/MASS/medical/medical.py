import socket
while(True):
    HOST = '172.26.82.154'                 # Symbolic name meaning all available interfaces
    PORT = 50115     # Arbitrary non-privileged port
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((HOST, PORT))
    s.listen(1)
    conn, addr = s.accept()
    print('Connected by', addr)

    data = conn.recv(1024)
    data1=str(data)
    print(data1)

#conn.send(data)
    conn.close()



