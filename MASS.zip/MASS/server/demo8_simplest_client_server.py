                                                                     
                                             

# coding: utf-8

# # Annotations for the Sirajology Python NN Example
# 
# This code comes from a demo NN program from the YouTube video https://youtu.be/h3l4qz76JhQ. The program creates an neural network that simulates the exclusive OR function with two inputs and one output. 
# 
# 

# In[23]:

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import numpy as np
import socket
import time
import random
import string
def nonlin(x, deriv=False):  # Note: there is a typo on this line in the video
        if(deriv==True):
            return (1/(1+np.exp(-x)))*(1-(1/(1+np.exp(-x))))
        return (1/(1+np.exp(-x)))  # Note: there is a typo on this line in the video


# The following code creates the input matrix. Although not mentioned in the video, the third column is for accommodating the bias term and is not part of the input. 

# In[25]:

#input data
X = np.array([
            [0,0,0,0,1],  # Note: there is a typo on this line in the video
            [0,0,0,1,1],
            [0,0,1,0,1],
            [0,0,1,1,1],
            [0,1,0,0,1],
            [0,1,0,1,1],
            [0,1,1,0,1],
            [0,1,1,1,1],
            [1,0,0,0,1],
            [1,0,0,1,1],
            [1,0,1,0,1],
            [1,0,1,1,1],
            [1,1,0,0,1],
            [1,1,0,1,1],
            [1,1,1,0,1],
            [1,1,1,1,1]])




# The output of the exclusive OR function follows. 

# In[26]:

#output data
y = np.array([[0.00],
             [0.06],
             [0.12],
             [0.18],
             [0.24],
             [0.30],
             [0.36],
             [0.42],
             [0.48],
             [0.54],
             [0.60],
             [0.66],
             [0.72],
             [0.78],
             [0.84],
             [0.90]])

# The seed for the random generator is set so that it will return the same random numbers each time, which is sometimes useful for debugging.

# In[27]:

np.random.seed(1)


# Now we intialize the weights to random values. syn0 are the weights between the input layer and the hidden layer.  It is a 3x4 matrix because there are two input weights plus a bias term (=3) and four nodes in the hidden layer (=4). syn1 are the weights between the hidden layer and the output layer. It is a 4x1 matrix because there are 4 nodes in the hidden layer and one output. Note that there is no bias term feeding the output layer in this example. The weights are initially generated randomly because optimization tends not to work well when all the weights start at the same value. Note that neither of the neural networks shown in the video describe the example. 

# In[28]:

#synapses
syn0 = 2*np.random.random((5,6)) - 1  # 3x4 matrix of weights ((2 inputs + 1 bias) x 4 nodes in the hidden layer)
syn1 = 1.99*np.random.random((6,1)) - 1  # 4x1 matrix of weights. (4 nodes x 1 output) - no bias term in the hidden layer.


# This is the main training loop. The output shows the evolution of the error between the model and desired. The error steadily decreases. 

# In[29]:

#print(syn0)
#print(syn1)
#training step
# Python2 Note: In the follow command, you may improve 
#   performance by replacing 'range' with 'xrange'.
#print("65300")
for j in range(65300):  
    
    # Calculate forward through the network.
        l0 = X
        l1 = nonlin(np.dot(l0, syn0))
        l2 = nonlin(np.dot(l1, syn1))
    
    # Back propagation of errors using the chain rule. 
        l2_error = y - l2
    #if(j % 10000) == 0:   # Only print the error every 10000 steps, to save time and limit the amount of output. 
        #print("Error: " + str(np.mean(np.abs(l2_error))))
       # print(syn0)
        
        l2_delta = l2_error*nonlin(l2, deriv=True)
    
        l1_error = l2_delta.dot(syn1.T)
    
        l1_delta = l1_error * nonlin(l1,deriv=True)
    
    #update weights (no learning rate term)
        syn1 += l1.T.dot(l2_delta)
        syn0 += l0.T.dot(l1_delta)
    
print("Output after training")
# Note: there is a typo on this line in the video


# The following is a function definition of the sigmoid function, which is the type of non-linearity chosen for this neural net. It is not the only type of non-linearity that can be chosen, but is has nice analytical features and is easy to teach with. In practice, large-scale deep learning systems use piecewise-linear functions because they are much less expensive to evaluate. 
# 
# The implementation of this function does double duty. If the deriv=True flag is passed in, the function instead calculates the derivative of the function, which is used in the error backpropogation step. 

# In[24]:
while True:
 value=""
 final_result=""
 HOST = '172.26.82.57'                 # Symbolic name meaning all available interfaces
 PORT = 50147       # Arbitrary non-privileged port
 s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
 s.bind((HOST, PORT))
 s.listen(1)
 conn, addr = s.accept()
 print('Connected by', addr)
 data = conn.recv(1024)
 value=str(data)
 #print(value)
#value="I have  swelling acidity diarrhoea nose cough throat fever cold"
#print(value)

  #  conn.send(data)

 stop_words = set(stopwords.words("english"))
 words = word_tokenize(value)
 filtered_sentence = []
 for w in words:
    if w not in stop_words:
        filtered_sentence.append(w)
 sequence=[0,0,0,0,1]
 value1 = np.array([
         [ 'cough','pain','fever','vomiting'],
         [ 'cough','pain','fever','diarrhoea'],
         [ 'dehydration','vomiting','weakness','diarrhoea'],
         [ 'diarrhoea','fever','vomiting','weakness'],
         [ 'acidity','pain','fever','vomiting'],
         ['headache','cough','fever','nose'],
         ['headache','pain','body','swelling'],
         ['headache','cough','throat','nose'],
         [ 'headache','cough','fever','weakness'],
         [ 'pain','fever','itching','swelling'],
         [ 'pain','weakness','bleeding','swelling'],
         [ 'cough','cold','throat','nose']
         ])

 value2=np.array([["cough"],['cold'],["pain"],["fever"],["vomiting"],["diarrhoea"],["dehydration"],["weakness"],["acidity"],["headache"],
                 ["nose"],["body"],["swelling"],["throat"],["itching"],["bleeding"],["cancer"],['hiv'],['typhoid'],["malaria"]])

 ct=0
 keys=[]
 for j in range(len(filtered_sentence)):
        for i in range(len(value2)):
            if(filtered_sentence[j]==value2[i]):
                keys.append(filtered_sentence[j])
            #ct=ct+1
#print(keys)
            
 lok=len(keys)
 current1=0

 while(current1<lok):
    #print(current1)
    sequence=[0,0,0,0,1]
#print(filtered_sentence)
    l=len(filtered_sentence)
    keywords_len=np.array([[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0],[0]])
    for k in range(12):
        for i in range(l):
            for j in range(4):
            #print(filtered_sentence[i],"&",value1[k][j])
                if(filtered_sentence[i]==value1[k][j]):
                    keywords_len[k]=keywords_len[k]+1
    ind = np.argmax(keywords_len)
#print(ind+1)
    
            #keywords = word_tokenize(value1)

#match = set(filtered_sentence) & set(value1)

#prin
    keywords=np.array([["nullnullnullnullnull"],["nullnullnullnullnull"],["nullnullnullnullnull"],["nullnullnullnullnull"]])
    nn=ind+1
    for j in range(4):
        for k in range(len(filtered_sentence)):
            if(filtered_sentence[k]==value1[ind][j]):
                keywords[j]=filtered_sentence[k]
                current1=current1+1
                sequence[j]=1
    sequence[j+1]=1
#print(nn)
#print(sequence)
    
    #"""if((sequence==[0,0,0,0,1])&(nn!=13)):
     #   nn=nn+1
        
    #else:
    #    break"""




    for i in range(16):
        a=np.array_equal(X[i],sequence)
        if(a==True):
            index=i
#        print(index)
            break
    


    if(nn==1):
     dict = {'0.00': 'Doctor is consulted to you -> Dr.Aniket Jadhav(8286926607)',
        '0.06': 'Ondem',
        '0.12': 'Paracetamol',
        '0.18': 'Paracetamol,Ondem',
        '0.24': 'Ibuprofen',
        '0.30': 'Ibuprofen,Ondem',
        '0.36': 'Paracetamol',
        '0.42': 'Paracetamol,Ondem',
        '0.48': 'Ascrol Flu Syrup',
        '0.54': 'Ascrol Flu Syrup,ondem',
        '0.60': 'Ascrol Flu Syrup,Paracetamol',
        '0.66': 'Ascrol Flu Syrup,Paracetamol,Ondem',
        '0.73': 'Ascrol Flu Syrup,Ibuprofene',
        '0.77': 'Ascrol Flu Syrup,Ibuprofene,Ondem',
        '0.84': 'Ascrol Flu Syrup,Ibuprofene,Paracetamol',
        '0.90': 'Ascrol Flu Syrup,Ibuprofene,Paracetamol,Ondem',
        }
    elif(nn==2):
     dict = {'0.00': 'null',
        '0.06': 'Metrogyl',
        '0.12': 'Paracetamol',
        '0.18': 'Paracetamol,Metrogyl',
        '0.24': 'Ibuprofen',
        '0.30': 'Ibuprofen,Metrogyl',
        '0.36': 'Ibuprofen,Paracetamol',
        '0.42': 'Ibuprofen,Paracetamol,Metrogyl',
        '0.48': 'Ascrol Flu Syrup',
        '0.54': 'Ascrol Flu Syrup,Metrogyl',
        '0.60': 'Ascrol Flu Syrup,Paracetamol',
        '0.66': 'Ascrol Flu Syrup,Paracetamol,Metrogyl',
        '0.73': 'Ascrol Flu Syrup,Ibupofen',
        '0.77': 'Ascrol Flu Syrup,Ibuprofene,Metrogyl',
        '0.84': 'Ascrol Flu Syrup,Paracetamol,Ibuprofen',
        '0.90': 'Ascrol Flu Syrup,Paracetamol,Ibuprofen,Metrogyl',
        }
    elif(nn==3):
     dict = {'0.00': 'null',
        '0.06': 'Metrogyl',
        '0.12': 'B-Plex',
        '0.18': 'Metogyl,B-Plex',
        '0.24': 'Ondem',
        '0.30': 'Metrogyl,Ondem',
        '0.36': 'B-Plex,Ondem',
        '0.42': 'Metrogyl,B-Plex,Ondem',
        '0.48': 'Electrolyte powder',
        '0.54': 'Metrogyl,Electrolyte powder,',
        '0.60': 'Electrolyte powder,B-Plex',
        '0.66': 'Metrogyl,Electrolyte powder,B-Plex',
        '0.73': 'Electrolyte powder,Ondem',
        '0.77': 'Metrogyl,Electrolyte powder,Ondem',
        '0.84': 'Electrolyte powder,B-Plex,Ondem',
        '0.90': 'Metrogyl,Electrolyte powder,B-Plex,Ondem',
        }
    elif(nn==4):
     dict = {'0.00': 'null',
        '0.06': 'B-Plex',
        '0.12': 'Ondem',
        '0.18': 'B-Plex,Ondem',
        '0.24': 'Paracetamol',
        '0.30': 'Paracetamol,B-Plex',
        '0.36': 'Paracetamol,Ondem',
        '0.42': 'Paracetamol,Ondem,B-Plex',
        '0.48': 'Metrogyl',
        '0.54': 'Metrogyl,B-Plex',
        '0.60': 'Metrogyl,Ondem',
        '0.66': 'Metrogyl,Ondem,B-Plex',
        '0.73': 'Metrogyl,Paracetamol',
        '0.77': 'Metrogyl,Paracetamol,B-Plex',
        '0.84': 'Metrogyl,Paracetamol,Ondem',
        '0.90': 'Metrogyl,Paracetamol,Ondem,B-Plex',
        }
    elif(nn==5):
     dict = {'0.00': 'null',
        '0.06': 'Ondem',
        '0.12': 'Paracetamol',
        '0.18': 'Ondem,Paracetamol',
        '0.24': 'Ibuprofen',
        '0.30': 'Ibuprofen,Ondem',
        '0.36': 'Ibuprofen,Paracetamol',
        '0.42': 'Ibuprofen,Paracetamol,Ondem',
        '0.48': 'RanTac',
        '0.54': 'RanTac,Ondem',
        '0.60': 'RanTac,Paracetamol',
        '0.66': 'RanTac,Paracetamol,Ondem',
        '0.73': 'RanTac,Ibuprofen',
        '0.77': 'RanTac,Ibuprofen,Ondem',
        '0.84': 'RanTac,Ibuprofen,Paracetamol',
        '0.90': 'RanTac,Ibuprofen,Paracetamol,Ondem'
        }
    elif(nn==6):
     dict = {'0.00':'null',
            '0.06':'Cetrizine',
            '0.12':'Paracetamol',
            '0.18':'Cetrizine,Paracetamol',
            '0.24':'Ascrol Flu Syrup',
            '0.30':'Ascrol Flu Syrup,Citrizine',
            '0.36':'Ascrol Flu Syrup,Paracetamol',
            '0.42':'Ascrol Flu Syrup,Paracetamol,Citrizine',
            '0.48':'Ibuprofen',
            '0.54':'Ibuprofen,Citrizine',
            '0.60':'Ibuprofen,Paracetamol',
            '0.66':'Ibuprofen,Paracetamol,Citrizine',
            '0.73':'Ibuprofen,Ascrol Flu Syrup',
            '0.77':'Ibuprofen,Ascrol Flu Syrup,Citrizine',
            '0.84':'Ibuprofen,Ascrol Flu Syrup,Paracetamol',
            '0.90':'Ibuprofen,Ascrol Flu Syrup,Paracetamol,Citrizine'
            }



    elif(nn==7):
     dict = {'0.00': 'null',
            '0.06':'Ibuprofen',
            '0.12':'Ibuprofen',
            '0.18':'Ibuprofen',
            '0.24':'Ibuprofen',
            '0.30':'Ibuprofen',
            '0.36':'Paracetamol,Ibuprofen',
            '0.42':'Ibuprofen',
            '0.48':'Paracetamol,Ibuprofen',
            '0.54':'Paracetamol,Ibuprofen',
            '0.60':'Paracetamol,Ibuprofen',
            '0.66':'Paracetamol,Ibuprofen',
            '0.73':'Paracetamol,Ibuprofen',
            '0.77':'Paracetamol,Ibuprofen',
            '0.84':'Paracetamol,Ibuprofen',
            '0.90':'Paracetamol,Ibuprofen',
            }

    elif(nn==8):
     dict = {'0.00':'null',
            '0.06':'Cetrizine',
            '0.12':'Azithromycine',
            '0.18':'Cetrizine,Azithromycine',
            '0.24':'Ascrol Flu',
            '0.30':'Ascrol Flu Syrup,Cetrizine',
            '0.36':'Ascrol Flu Syrup, Azithromycine',
            '0.42':'Ascrol Flu Syrup, Azithromycine,Cetrizine',
            '0.48':'Paarcetamol',
            '0.54':'Paarcetamol,Cetrizine',
            '0.60':'Paracetamol,Azithromycine',
            '0.66':'Paracetamol,Azithromycine,Cetrizine',
            '0.73':'Paracetamol,Ascrol Flu Syrup',
            '0.77':'Paracetamol,Ascrol Flu Syrup,Cetrizine',
            '0.84':'Paracetamol,Ascrol Flu Syrup,Azithromycine',
            '0.90':'Paracetamol,Ascrol Flu Syrup,Azithromycine,Cetrizine'
            }

    elif(nn==9):
     dict = {'0.00':'null',
            '0.06':'B-Plex',
            '0.12':'Paracetamol',
            '0.18':'Paracetamol,B-Plex',
            '0.24':'Ascrol Flu Syrup',
            '0.30':'Ascrol Flu Syrup,B-Plex',
            '0.36':'Ascrol Flu Syrup,Paracetamol',
            '0.42':'Ascrol Flu Syrup,Paracetamol,B-Plex',
            '0.48':'Paracetamol',
            '0.54':'Paracetamol,B-Plex',
            '0.60':'Paracetamol',
            '0.66':'Paracetamol,B-Plex',
            '0.73':'Paracetamol,Ascrol Flu Syrup',
            '0.77':'Paracetamol,Ascrol Flu Syrup,B-Plex',
            '0.84':'Paracetamol,Ascorl Syrup',
            '0.90':'Paracetamol,Ascrol Flu Syrup,B-Plex'
            }

    elif(nn==10):
     dict = {'0.00':'null',
            '0.06':'Ibuprofen',
            '0.12':'Avil',
            '0.18':'Ibuprofen,Avil',
            '0.24':'Paracetamol',
            '0.30':'Paracetamol,Ibuprofen',
            '0.36':'Paracetamol,Avil',
            '0.42':'Paracetamol,Avil,Ibuprofen',
            '0.48':'Ibuprofen',
            '0.54':'Ibuprofen',
            '0.60':'Ibuprofen,Avil',
            '0.66':'Ibuprofen,Avil',
            '0.73':'Ibuprofen,Paracetamol',
            '0.77':'Ibuprofen,Paracetamol,Avil',
            '0.84':'Paracetamol,Avil,Ibuprofen',
            '0.90':'Paracetamol,Avil,Ibuprofen'
            }
    elif(nn==11):
     dict = {'0.00':'null',
            '0.06':'Ibuprofen',
            '0.12':'Trenexa',
            '0.18':'Ibuprofen,Trenexa',
            '0.24':'B-Plex',
            '0.30':'B-Plex,Ibuprofen',
            '0.36':'B-Plex,Trenexa',
            '0.42':'B-Plex,Trenexa,Ibuprofen',
            '0.48':'Ibuprofen',
            '0.54':'Ibuprofen',
            '0.60':'Ibuprofen,Trenexa',
            '0.66':'Ibuprofen,Trenexa',
            '0.73':'Ibuprofen,B-Plex',
            '0.77':'Ibuprofen,B-Plex',
            '0.84':'Ibuprofen,B-Plex,Trenexa',
            '0.90':'Ibuprofen,B-Plex,Trenexa'
            }
    elif(nn==12):
     dict = {'0.00':'null',
            '0.06':'Cetrizine',
            '0.12':'Azithromycine',
            '0.18':'Azithromycine,Cetrizine',
            '0.24':'Ascrol Flu Syrup',
            '0.30':'Ascrol Flu Syrup,Cetrizine',
            '0.36':'Ascrol Flu Syrup,Azithromycine',
            '0.42':'Ascrol Flu Syrup,Azithromycine,Cetrizine',
            '0.48':'Ascrol Flu Syrup',
            '0.54':'Ascrol Flu Syrup,Cetrizine',
            '0.60':'Ascrol Flu Syrup,Azithromycine',
            '0.66':'Ascrol Flu Syrup,Azithromycine,Cetrizine',
            '0.73':'Ascrol Flu Syrup',
            '0.77':'Ascrol Flu Syrup,Cetrizine',
            '0.84':'Ascrol Flu Syrup,Azithromycine',
            '0.90':'Ascrol Flu Syrup,Azithromycine,Cetrizine'
            }

    result="%.2f" %l2[index]
    if(sequence==[0,0,0,0,1]):
        final_result+=str(dict[result])+" For : "+str(keys[0])+"\n"
        keys = np.delete(keys,0)
        current1=current1+1
        continue
    else:
        final_result+=str(dict[result])+" For : "+str(np.intersect1d(keys,keywords))+"\n"

    cp=[]
    filtered_sentence=[]
    for j in range(len(keys)):
       if(np.intersect1d(keys[j],keywords)):
          cp.append(j)
          continue
       else:
         # print(keys[j],"appended")
          filtered_sentence.append(keys[j])
   # print(cp)
   # print(len(keys))
    for i in range(len(cp)):
        keys = np.delete(keys,cp[len(cp)-1-i])
   # print(keys)
 somecode = 'asdfln3j34tnonfdkjnflksdfnla'
 message = final_result

 def str_xor(s1, s2):
  return "".join([chr(ord(c1) ^ ord(c2)) for (c1,c2) in zip(s1,s2)])

 encoded = str_xor(message, somecode)
# encoded == '\x15\x1b\r\x15L\x07@J^MT\x03\n\x1d\x15\x05\x0c\x0f'
 print (encoded)
 decoded = str_xor(encoded, somecode)
# decoded == 'this is my message'
#print (decoded)
 print(encoded)
#print(decoded)
 encoded = str_xor("A doctor is consulted for other symptops if you have", somecode)
#print("A doctor is consulted for other symptops if you have")
 print(encoded)
#print(decoded)
 if(final_result==""):
         conn.send("No Prescriptions Available ! \n A doctor is consulted for other symptops if you have !")
         conn.close()
 else:
         HOST = '172.26.82.61'    # The remote host  DOCTOR
         PORT = 50157       # The same port as used by the server
         s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
         s.connect((HOST, PORT))

#if(dict[result]=="null"):
    #print("doctor is consulted to you : \n Dr.Aniket Jadhav-8286926607")
 #   encoded = str_xor("doctor is consulted to you : \n Dr.Aniket Jadhav-8286926607", somecode)
  #  conn.send(bytes(encoded))
   # s.close()
    #conn.send(dict[result])
#else:
    #print (dict[result])
#aniket=encoded
         s.send(final_result)
        
         s.close()
    
    #s.send(dict[result])
    
#recieve result from doctor and send to client
     
         HOST = '172.26.82.57'                 # Symbolic name meaning all available interfaces MASS
         PORT = 50169     # Arbitrary non-privileged port
         s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
         s.bind((HOST, PORT))
         s.listen(1)
         conn1, addr = s.accept()
         print('Connected by', addr)
#while True:
         data = conn1.recv(1024)
         value=str(data)
         code=''.join(random.choice(string.ascii_uppercase +string.ascii_lowercase+ string.digits) for _ in range(8))
         #value="OK"
 #value="I have fever//// and cough"
    #print(value)
         HOST = '172.26.82.154'    # The remote host  DOCTOR
         PORT = 50115 #The same port as used by the server
         s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
         s.connect((HOST, PORT))
         if(value=="OK"):
                 conn.send("\n Unique Code : "+code+"\n"+final_result+"\n You are consulted to refer doctor within 12 hrs !")
                 s.send("Unique Code : "+code+"\n"+final_result+"\n You are consulted to refer doctor within 12 hrs !")
         elif(final_result==""):
                 conn.send("No Prescriptions available!")
         else:
                 conn.send("\n Unique Code : "+code+"\n"+value+"\n You are consulted to refer doctor within 10 hrs !")
                 s.send("Unique Code : "+code+"\n"+value+"\n You are consulted to refer doctor within 12 hrs !")
#if(final_result==""):
#        conn.send(bytes("No Prescriptions available!"))
#else:
#        conn.send(bytes(final_result))\
        
        # print(value)
         s.close()
        # s.send(bytes(value,'utf-8'))
         conn.close()
