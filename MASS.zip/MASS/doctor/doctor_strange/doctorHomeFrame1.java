import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class doctorHomeFrame1 extends JFrame{

JLabel l1;
JTextArea ta;
Container c=null;
JScrollPane sp1;
JButton okk;

public doctorHomeFrame1(){

 super("Doctor Strange System");
 c= getContentPane();
 c.setLayout(null);
 setSize(500,250);
 setResizable(false);
 setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

 //l1=new JLabel("Id: 1001");
// listen=new JButton("Listen");
 //retry=new JButton("Retry");
 okk=new JButton("Okk");
 ta=new JTextArea(10,10);
 ta.setEditable(true);
 
 sp1=new JScrollPane(ta);
 sp1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
 sp1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
 sp1.setBounds(50,10,350,100);

 //l1.setBounds(420,0,400,50);
// listen.setBounds(80,140,80,30);
 //retry.setBounds(190,140,120,30);
 okk.setBounds(350,140,80,30);
 ta.setText("");

 okk.setEnabled(true);
 //listen.setEnabled(false);


 //c.add(l1);
// c.add(listen);
// c.add(retry);
 c.add(okk);
 c.add(sp1);

 //ta.setText("gdhqhvdaAGDHYadADBHabdjANDKdKJDKajdlALDadahNMNDMSNDMNSJDHSAJHDJABDJNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNJSAAAAAAAAAAAAAAAAAAAAAAAAA");
 //add(c);

setLocationRelativeTo(null);
setVisible(true);
/*try{
File f2=new File("C:/Users/ashwinkumar/Desktop/javagui/medicine.txt");
String c=new String(Files.readAllBytes(Paths.get("C:/Users/ashwinkumar/Desktop/javagui/medicine.txt")));
ta.setText("You are prescribed as follows:\n"+c);
}
catch(Exception e){System.out.println(e);}*/
 addWindowListener(new WindowAdapter(){
 public void windowClosing(WindowEvent e)
 {
  int output=JOptionPane.showConfirmDialog(new JDialog(),"Do You Want To Exit ?");
  if(output==JOptionPane.YES_OPTION)
  {
   System.exit(1);
  }
 }
 });

/*listen.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae){
 try{
 File f=new File("C:/Users/SIF-/Desktop/hello.txt");
 boolean b=f.delete();
 Runtime runTime = Runtime.getRuntime();
 Process process = runTime.exec("C:/Users/SIF-/Desktop/startPython.bat");
 //process.destroy();
 //Thread t=new Thread();
 //t.sleep(15000);
 while(f.exists()==false){continue;}
 String content = new String(Files.readAllBytes(Paths.get("C:/Users/SIF-/Desktop/hello.txt")));
 ta.setText(content);
 retry.setEnabled(true);
 ok.setEnabled(true);
 listen.setEnabled(false);
 
}
 catch(Exception e){System.out.println(e);}
}
});
retry.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae)
{
try{
 dispose();
 HomeFrame h=new HomeFrame(); 
}
 catch(Exception e){System.out.println(e);}
}
});

*/
//File f=new File("c:/Users/Mayur/Desktop/medicine.txt");
//while(f.exists()==false){continue;}
try{
 String content = new String(Files.readAllBytes(Paths.get("C:/Users/Mayur/Desktop/doctor_strange/medicine.txt")));
 ta.setText(content);
 
}
catch(Exception e){System.out.println(e);}


okk.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent ae)
{
 try{
	
     String mod=ta.getText();
     System.out.println(mod);
	  try {
            //String str = "SomeMoreTextIsHere";
          File newTextFile = new File("C:/Users/Mayur/Desktop/doctor_strange/medicine.txt");

          // BufferedWriter bw  = new BufferedWriter(new FileWriter("C:/Users/Mayur/Desktop/medicine.txt",true));
			 BufferedWriter bw1  = new BufferedWriter(new FileWriter("C:/Users/Mayur/Desktop/doctor_strange/history.txt",true));
	FileWriter fw = new FileWriter(newTextFile);
	fw.write(mod);
	fw.close();
	
			//BufferedWriter bw = new BufferedWriter(fw);
			//PrintWriter p = new PrintWriter(bw);
			
			bw1.newLine();
            bw1.write("Modified---"+mod);
			//bw1.newLine();
			
			bw1.close();
          // fw.close();
            
        } catch (IOException iox) {
            //do stuff with exception
            iox.printStackTrace();
        }
		Runtime runTime = Runtime.getRuntime();
     Process process = runTime.exec("c:/Users/Mayur/Desktop/doctor_strange/sendMass.bat");
System.exit(1);
 
}
 catch(Exception e){System.out.println(e);}
}
}
);

try{
Thread t =new Thread();
t.sleep(50000);
try{
	
     String mod=ta.getText();
     System.out.println(mod);
	  try {
            //String str = "SomeMoreTextIsHere";
            File newTextFile = new File("C:/Users/Mayur/Desktop/doctor_strange/medicine.txt");

            FileWriter fw = new FileWriter(newTextFile);
            fw.write(mod);
            fw.close();
            
        } catch (IOException iox) {
            //do stuff with exception
            iox.printStackTrace();
        }
		Runtime runTime = Runtime.getRuntime();
     Process process = runTime.exec("c:/Users/Mayur/Desktop/doctor_strange/sendMass.bat");
System.exit(0);
 
}
 catch(Exception e){System.out.println(e);}
}

 catch(Exception e){System.out.println(e);}

}
public static void main(String args[])
{
doctorHomeFrame1 h=new doctorHomeFrame1();
}
}
