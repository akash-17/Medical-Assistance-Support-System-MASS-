import socket

    
HOST = '172.26.82.57'    # The remote host
PORT = 50169  # The same port as used by the server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
f=open("C:/Users/Mayur/Desktop/doctor_strange/medicine.txt","r")
a=f.read()
f.close()

s.send(bytes(a,'utf-8'))
#data = s.recv(1024)
s.close()
#print('Received', repr(data)
