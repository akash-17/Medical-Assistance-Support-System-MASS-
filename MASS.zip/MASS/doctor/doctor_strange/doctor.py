import socket
import os
import datetime

while(True):
    
   HOST = '172.26.82.61'                
   PORT = 50157

   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   s.bind((HOST, PORT))
   s.listen(1)
   conn, addr = s.accept()
   print('Connected by', addr)

   data = conn.recv(1024)
   data1=str(data,"utf-8")
   now = datetime.datetime.now()

   print(data1)
   f1=open("C:/Users/Mayur/Desktop/doctor_strange/medicine.txt",'w+')
   b=data1

   f1.write(b)
   f1.close()

   f2=open("C:/Users/Mayur/Desktop/doctor_strange/history.txt",'a')

   d1=str(now)
   f2.write('\n')
   f2.write(d1)
   f2.write('\n')



   f2.write(b)

   f2.close()
   os.system("C:/Users/Mayur/Desktop/doctor_strange/runjava.bat")

#conn.send(data)
   conn.close()



